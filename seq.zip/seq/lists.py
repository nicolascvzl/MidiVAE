from typing import Generic, Iterator, Optional, TypeVar

T = TypeVar('T')


class Node(Generic[T]):
    _data: T
    _next: Optional['Node[T]']
    _prev: Optional['Node[T]']

    def __init__(self, data):
        self._data = data
        self._next = None
        self._prev = None

    def __eq__(self, other):
        """
        Only checks data, not next and previous nodes

        :param other:
        :return:
        """
        if isinstance(self, other.__class__):
            if self.data == other.data:
                return True
        return False

    def __str__(self):
        return f'Node: {str(self.data)}'

    @property
    def data(self) -> T:
        return self._data

    @data.setter
    def data(self, value) -> None:
        self._data = value

    @property
    def next_node(self) -> 'Node[T]':
        return self._next

    @next_node.setter
    def next_node(self, node: 'Node[T]'):
        self._next = node

    @property
    def prev_node(self) -> 'Node[T]':
        return self._prev

    @prev_node.setter
    def prev_node(self, node: 'Node[T]'):
        self._prev = node


class LinkedList(Generic[T]):
    _head: Optional[Node[T]]
    _tail: Optional[Node[T]]

    def __init__(self):
        self._head = self._tail = None

    def __eq__(self, other):
        if isinstance(self, other.__class__):
            crt, other_crt = self.head, other.head
            while crt == other_crt:
                if crt is None and other_crt is None:
                    return True
                crt, other_crt = crt.next_node, other_crt.next_node
            return False
        return False

    def __iter__(self):
        crt = self.head
        while crt is not None:
            yield crt
            crt = crt.next_node

    def __str__(self):
        return f'{self.head} --> {self.tail}'

    @property
    def head(self) -> Node[T]:
        return self._head

    @property
    def tail(self) -> Node[T]:
        return self._tail

    def is_empty(self) -> bool:
        return self.head is None

    def append(self, node: Node[T]):
        if self.is_empty():
            self._head = self._tail = node
            node.prev_node = None
        else:
            self._tail.next_node = node
            node.prev_node = self.tail
            self._update_tail(node)

    def _update_tail(self, starting_node: Node[T]):
        n = starting_node
        while n is not None:
            self._tail = n
            n = n.next_node

    def remove(self, node: Node[T]):
        prev = node.prev_node
        succ = node.next_node
        if prev and succ:
            prev.next_node = succ
            succ.prev_node = prev
        elif prev:
            prev.next_node = None
            self._tail = prev
        elif succ:
            succ.prev_node = None
            self._head = succ
        else:
            self._head = self._tail = None

    def insert_before(self, node: Node[T], next_node: Node[T]):
        if next_node is None:
            self.append(node)
        else:
            node.next_node = next_node
            former_prev = next_node.prev_node
            next_node.prev_node = node
            if next_node == self.head:
                self._head = node
                node.prev_node = None
            else:
                node.prev_node = former_prev
                former_prev.next_node = node


class GenericList(Generic[T]):
    def __init__(self):
        self.elements = []
        self._empty = True

    def __eq__(self, other):
        if isinstance(self, other.__class__):
            return self.elements == other.elements
        return False

    def __iter__(self) -> Iterator[T]:
        return self.elements.__iter__()

    def __str__(self):
        return self.elements.__str__()

    def __getitem__(self, i):
        return self.elements.__getitem__(i)

    def __len__(self):
        return self.elements.__len__()

    @property
    def head(self) -> T:
        if self.empty:
            return None
        return self.elements[0]

    @property
    def tail(self) -> T:
        if self.empty:
            return None
        return self.elements[-1]

    @property
    def empty(self) -> bool:
        return self._empty

    def append(self, element: T):
        self.elements.append(element)
        self._empty = False

    def remove(self, element: T):
        self.elements.remove(element)
        self._empty = len(self.elements) == 0

    def insert_before(self, element: T, next_element: T):
        if next_element is None:
            self.append(element)
            return
        if next_element not in self.elements:
            raise ValueError('oups')
        idx = self.elements.index(next_element)
        self.insert(idx, element)

    def insert(self, idx: int, element: T):
        self.elements.insert(idx, element)
        self._empty = False
