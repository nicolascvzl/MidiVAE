import os
from copy import copy
from typing import Dict, List, Optional, Tuple

import numpy as np
from midi import AbstractEvent, ChannelPrefixEvent, ControlChangeEvent, EndOfTrackEvent, Event, FileReader, \
    FileWriter, \
    InstrumentNameEvent, NoteOffEvent, NoteOnEvent, Pattern, PortEvent, SetTempoEvent, TimeSignatureEvent, Track, \
    TrackNameEvent
from numpy import count_nonzero
from numpy.ma import logical_xor

from seq.interval import Interval
from seq.smart_seq import SmartSequence, Splitable
from seq.track import SmartTrack


class SmartMultiTrack(Splitable):
    name: str
    _parent: Optional['SmartMultiTrack']
    resolution: int
    midi_tracks: List[Track]
    smart_tracks: List[SmartTrack]
    _duration: int
    _time_sig: Tuple[int, int]
    _tempo: int
    # original is None except for transposed SmartMultiTracks, in which case it is the original non-transposed track
    original: None
    _residual_ratio: float
    _atomic_size: int
    _smart: bool
    # the preceding SmartMultiTrack of this one, if any, otherwise None
    _pred: 'SmartMultiTrack'
    # the successor SmartMultiTrack of this one, if any, otherwise None
    _succ: 'SmartMultiTrack'
    # the superimposed matrices of the smart tracks in this multitrack
    _matrices: Dict[int, np.ndarray]
    # the superimposed matrices, modulo 12, of the smart tracks in this multitrack
    _matrices_mod12: Dict[int, np.ndarray]

    creation_index = 0

    def __init__(self,
                 name: str,
                 parent=None,
                 initial_start: int = 0,
                 resolution=480,
                 duration=0,
                 time_sig=None,
                 tempo: int = 120,
                 smart: bool = True,
                 atomic_size: int = 30,
                 residual_ratio: float = 0.25):
        self._creation_index = SmartMultiTrack.creation_index
        SmartMultiTrack.creation_index += 1
        self._parent = parent if parent is not None else self
        self._semitones = 0
        self._initial_start = initial_start
        self.name = name
        self.resolution = resolution
        self._duration = duration
        self.midi_tracks = []
        self.smart_tracks = []
        self._time_sig = time_sig
        self.original = None
        self._tempo = tempo
        self._smart = smart
        self._atomic_size = atomic_size
        self._residual_ratio = residual_ratio
        self._pred = self._succ = None
        self._matrices = {}
        self._matrices_mod12 = {}

    def __str__(self):
        s = f'{self.name} ' \
            f', ({self.semitones} semitones)' \
            f'{self.ticks_to_beats(self.duration)} beat(s)'
        # s += f'\nextracted from {self.parent.name if self.parent else "None"} ' \
        #      f'at initial position {self.ticks_to_beats(self.initial_start)}'
        # for i, smart_track in enumerate(self.smart_tracks):
        #     s += f'\n\tTrack #{i}: {smart_track}'
        return s

    def __copy__(self):
        raise TypeError('should not be called')

    def __deepcopy__(self, memodict):
        raise TypeError('should not be called')

    def empty_copy(self, duration: int):
        return SmartMultiTrack(name='empty',
                               duration=duration,
                               time_sig=self.time_sig,
                               atomic_size=self.atomic_size,
                               residual_ratio=self.residual_ratio)

    def copy(self):
        res = SmartMultiTrack(name=self.name,
                              parent=self.parent,
                              initial_start=self.initial_start,
                              resolution=self.resolution,
                              duration=self.duration,
                              time_sig=self.time_sig,
                              atomic_size=self.atomic_size,
                              residual_ratio=self.residual_ratio)
        res.tempo = self.tempo
        for midi_track in self.midi_tracks:
            res.midi_tracks.append(copy(midi_track))
        for smart_track in self.smart_tracks:
            res.smart_tracks.append(smart_track.copy())
        return res

    def matrix(self, n_bins: int = 0) -> np.ndarray:
        n_bins = self.duration if n_bins == 0 else n_bins

        # check if matrix is already computed
        if n_bins in self._matrices:
            return self._matrices[n_bins]

        # compute matrix
        mat = np.zeros((128, n_bins), dtype=bool)
        for t in self.smart_tracks:
            mat = np.logical_or(mat, t.matrix(n_bins))

        self._matrices[n_bins] = mat
        return mat

    def matrix_mod12(self, n_bins: int = 0) -> np.ndarray:
        n_bins = self.duration if n_bins == 0 else n_bins

        # check if matrix is already computed
        if n_bins in self._matrices_mod12:
            return self._matrices_mod12[n_bins]

        # compute matrix
        mat = np.zeros((12, n_bins), dtype=bool)
        for t in self.smart_tracks:
            mat = np.logical_or(mat, t.matrix_mod12(n_bins))

        self._matrices_mod12[n_bins] = mat
        return mat

    def invalidate_matrices(self):
        for track in self.smart_tracks:
            track.invalidate_matrices()

    @property
    def parent(self) -> 'SmartMultiTrack':
        return self._parent

    @parent.setter
    def parent(self, pr: 'SmartMultiTrack'):
        self._parent = pr

    @property
    def initial_start(self) -> int:
        return self._initial_start

    @initial_start.setter
    def initial_start(self, start: int):
        self._initial_start = start

    @property
    def semitones(self) -> int:
        return self._semitones

    @semitones.setter
    def semitones(self, st: int):
        self._semitones = st

    @property
    def empty(self) -> bool:
        for st in self.smart_tracks:
            if not st.empty:
                return False
        return True

    @property
    def duration(self) -> int:
        return self._duration

    @duration.setter
    def duration(self, new_duration: int):
        self._duration = new_duration
        for midi_track in self.midi_tracks:
            self.set_duration(midi_track, new_duration)
        for smart_track in self.smart_tracks:
            self.set_duration(smart_track, new_duration)

    @property
    def tempo(self) -> int:
        return self._tempo

    @tempo.setter
    def tempo(self, new_tempo: int):
        self._tempo = new_tempo
        for midi_track in self.midi_tracks:
            for event in midi_track:
                if isinstance(event, SetTempoEvent):
                    event.set_bpm(new_tempo)
        for smart_track in self.smart_tracks:
            smart_track.tempo = new_tempo

    @property
    def time_sig(self) -> Tuple[int, int]:
        return self._time_sig

    @property
    def smart(self) -> bool:
        return self._smart

    @smart.setter
    def smart(self, b):
        for track in self.smart_tracks:
            track.smart = b

    @property
    def atomic_size(self) -> int:
        return self._atomic_size

    @atomic_size.setter
    def atomic_size(self, new_atomic_size):
        for track in self.smart_tracks:
            track.atomic_size = new_atomic_size
        self._atomic_size = new_atomic_size

    @property
    def residual_ratio(self) -> float:
        return self._residual_ratio

    @residual_ratio.setter
    def residual_ratio(self, new_residual_ratio):
        for track in self.smart_tracks:
            track.residual_ratio = new_residual_ratio
        self._residual_ratio = new_residual_ratio

    @property
    def pred(self) -> 'SmartMultiTrack':
        return self._pred

    @pred.setter
    def pred(self, pr: 'SmartMultiTrack'):
        self._pred = pr

    @property
    def succ(self) -> 'SmartMultiTrack':
        return self._succ

    @succ.setter
    def succ(self, pr: 'SmartMultiTrack'):
        self._succ = pr

    def num_bars(self) -> int:
        return int(self.ticks_to_beats(self.duration) / self.time_sig[0])

    @classmethod
    def read(cls,
             file_name: str,
             name: str = 'no_name',
             atomic_size_in_beats: float = 0.0,
             residual_ratio: float = 0.0,
             smart: bool = True,
             show_warnings: bool = False,
             ignore_midi_tracks: bool = True,
             ignore_drum: bool = False) -> 'SmartMultiTrack':
        """
        Read a MIDI file

        :param name:
        :param file_name:
        :param show_warnings:
        :return:
        """
        with open(file_name, 'rb') as mf:
            pattern = FileReader().read(mf)
            pattern.make_ticks_abs()

        res = SmartMultiTrack(name=name,
                              parent=None,
                              initial_start=0,
                              smart=smart,
                              resolution=pattern.resolution,
                              residual_ratio=residual_ratio)
        res.atomic_size = int(res.beats_to_ticks(1) * atomic_size_in_beats)

        # sort tracks, just in case
        end = 0
        for track_idx, raw_midi_track in enumerate(pattern):
            raw_midi_track.sort(key=lambda x: x.tick, reverse=False)
            end = max(end, raw_midi_track[-1].tick)

        d, m = divmod(end, res.resolution)
        res._duration = (d + (0 if m == 0 else 1)) * res.resolution

        for track_idx, raw_midi_track in enumerate(pattern):
            if raw_midi_track[-1].tick:
                ev = raw_midi_track[-1]
                if not isinstance(ev, EndOfTrackEvent):
                    raise ValueError(f'Track {raw_midi_track} ends with {ev}, should be "EndOfTrackEvent"')
                ev.tick = res._duration

        for raw_midi_track in pattern:
            track = res.smart_track(raw_midi_track=raw_midi_track,
                                    show_warnings=show_warnings,
                                    atomic_size=res.atomic_size,
                                    smart=res.smart,
                                    residual_ratio=res.residual_ratio,
                                    ignore_drum=ignore_drum)
            if track is None:
                if not ignore_midi_tracks:
                    res.add_midi_track(raw_midi_track)
            else:
                res.add_smart_track(track)

        # Trying to get the tempo of the original midi file
        tempo = None
        for midi_track in res.midi_tracks:
            _tempo = res.get_tempo(midi_track)
            if _tempo is None and tempo is None:
                pass
            elif _tempo is None and tempo is not None:
                pass
            elif _tempo is not None and tempo is None:
                tempo = _tempo
            else:
                if tempo != _tempo:
                    raise ValueError(f'cannot parse midi files with different tempos')
        for smart_track in res.smart_tracks:
            _tempo = res.get_tempo(smart_track)
            if _tempo is None and tempo is None:
                pass
            elif _tempo is None and tempo is not None:
                pass
            elif _tempo is not None and tempo is None:
                tempo = _tempo
            else:
                if tempo != _tempo:
                    raise ValueError(f'cannot parse midi files with different tempos')
        if tempo is None:
            cls.warning(f'did not find tempo in midi file {file_name}')
            tempo = 120
        res.tempo = tempo
        return res

    def pad_by(self, ticks: int):
        self.duration += ticks

    def pad_to_next_bar(self):
        d, m = divmod(self.duration, (self.time_sig[0] * self.resolution))
        if m != 0:
            new_duration = (d + 1) * self.time_sig[0] * self.resolution
            self.duration = new_duration

    @staticmethod
    def is_note_off(event: Event) -> bool:
        return isinstance(event, NoteOffEvent) \
               or (isinstance(event, NoteOnEvent) and event.data[-1] == 0)

    @staticmethod
    def is_note_on(event: Event) -> bool:
        return isinstance(event, NoteOnEvent) and event.data[-1] > 0

    def write(self, file_name: str):
        if not file_name.endswith('.mid'):
            raise ValueError(f'wrong file name {file_name} should end with ".mid"')
        pattern = Pattern()
        pattern.resolution = self.resolution
        if self.tempo and not self.has_tempo_event():
            self.tempo = self.tempo
        for smart_track in self.smart_tracks:
            pattern.append(self.raw_midi_track(smart_track))
        for midi_track in self.midi_tracks:
            pattern.append(midi_track)
        with open(file_name, 'wb') as mf:
            FileWriter(mf).write(pattern)

    def add_smart_track(self, smart_track: SmartTrack):
        if self.smart_tracks:
            if smart_track.duration != self.duration:
                raise ValueError(f'cannot put track with duration {smart_track.duration} '
                                 f'in a piano roll of duration {self.duration}')
        self.smart_tracks.append(smart_track)
        self._duration = smart_track.duration

    def add_midi_track(self, midi_track: Track):
        self.midi_tracks.append(midi_track)

    def smart_track(self, raw_midi_track: Track,
                    show_warnings: bool,
                    smart: bool,
                    atomic_size: int,
                    residual_ratio: float,
                    ignore_drum: bool = False) -> Optional[SmartTrack]:
        """
        Return the SmartTrack constructed from the raw MIDI track parameter or None if the raw MIDI track is of
        zero duration

        :param show_warnings:
        :param raw_midi_track:
        :return:
        """
        if raw_midi_track[-1].tick == 0:
            return None
        found_notes = False
        found_time_sig = False
        for event in raw_midi_track:
            if self.is_note_on(event):
                found_notes = True
            if isinstance(event, TimeSignatureEvent):
                if found_time_sig:
                    raise ValueError(f'track {raw_midi_track} has time signature changes')
                else:
                    found_time_sig = True
        if not found_notes:
            return None

        self._put_note_off_events_before_note_on_events(raw_midi_track)
        res = SmartTrack(duration=raw_midi_track[-1].tick,
                         smart=smart,
                         atomic_size=atomic_size,
                         residual_ratio=residual_ratio)
        res.put_sequence(-1, SmartSequence(res.duration,
                                           segmentation_step=self.resolution,
                                           atomic_size=atomic_size,
                                           residual_ratio=residual_ratio))
        last_note_on_dict = {}
        tempo_event_processed = False
        for event in raw_midi_track:  # type: Event
            tick = event.tick
            if isinstance(event, TrackNameEvent):
                res.name = event.text
                res.sequence(-1).append(Interval(tick, tick, event))
                res.sequence(-1).append(Interval(tick, tick, ControlChangeEvent(tick=0, channel=0, data=[127, 0])))
            elif isinstance(event, InstrumentNameEvent):
                if not tick == 0:
                    if show_warnings:
                        self.warning('instrument event {event} not at beginning of track (tick={tick})')
                event.tick = 0
                res.sequence(-1).append(Interval(0, 0, event))
            elif isinstance(event, TimeSignatureEvent):
                new_time_sig = (event.numerator, event.denominator)
                if self.time_sig and self.time_sig != new_time_sig:
                    raise ValueError(f'cannot read midi files with multiple key signatures '
                                     f'{self.time_sig} and {new_time_sig} in track {res.name} '
                                     f'at tick {event.tick}')
                res.sequence(-1).append(Interval(event.tick, event.tick, event))
                self._time_sig = (event.numerator, event.denominator)
            elif isinstance(event, (PortEvent, ChannelPrefixEvent, ControlChangeEvent)):
                if tick == 0:
                    res.sequence(-1).append(Interval(event.tick, event.tick, event))
                else:
                    if show_warnings:
                        self.warning(f'ignores event {event}, because it is not a beginning of track')
            elif isinstance(event, EndOfTrackEvent):
                if tick == res.duration:
                    res.sequence(-1).append(Interval(event.tick, event.tick, event))
                else:
                    if show_warnings:
                        self.warning(f'ignores event {event}, because it is not at end of track')
            elif isinstance(event, SetTempoEvent):
                if tick == 0 and not tempo_event_processed:
                    res.sequence(-1).append(Interval(event.tick, event.tick, event))
                    res._tempo = event.get_bpm()
                    tempo_event_processed = True
                else:
                    if show_warnings:
                        self.warning(f'ignores event {event}, because it is not at beginning of track or not first '
                                     f'in track')
            elif self.is_note_on(event):
                pitch = event.data[0]
                velocity = event.data[-1]
                channel = event.channel
                if channel == 9 and not ignore_drum:
                    res._is_drum = True
                if channel == 9 and ignore_drum:
                    # print(f'skipped note on event {event} because it is drum')
                    continue
                if pitch in last_note_on_dict:
                    # two consecutive note-on events
                    if show_warnings:
                        self.warning(f'track {res.name} has two consecutive note-on events for pitch {pitch} '
                                     f'at {last_note_on_dict[pitch][0]} '
                                     f'and {tick}')
                else:
                    last_note_on_dict[pitch] = (tick, velocity, event.channel)
            elif self.is_note_off(event):
                pitch = event.data[0]
                tick = event.tick
                channel = event.channel
                if channel == 9 and not ignore_drum:
                    # this is probably redundant as the note on with same pitch/channel came first
                    res._is_drum = True
                if channel == 9 and ignore_drum:
                    # print(f'skipped note off event {event} because it is drum')
                    continue
                if not res.has_key(pitch):
                    res.put_sequence(pitch, SmartSequence(res.duration,
                                                          segmentation_step=self.resolution,
                                                          atomic_size=atomic_size,
                                                          residual_ratio=residual_ratio))
                if not pitch in last_note_on_dict:
                    # missing note on event
                    if show_warnings:
                        self.warning(f'track {res.name} has a note-off event for pitch {pitch} '
                                     f'at {tick} but no note-on event')
                else:
                    res.sequence(pitch).append(Interval(last_note_on_dict[pitch][0],
                                                        tick,
                                                        last_note_on_dict[pitch][1:]))
                    del last_note_on_dict[pitch]
            else:
                if show_warnings:
                    self.warning(f'ignores midi event {type(event)} in track {res.name} at tick {tick}')
        if self.time_sig is None:
            if show_warnings:
                self.warning('no time signature event found, uses 4/4')
            self._time_sig = (4, 4)
        return res

    @staticmethod
    def raw_midi_track(smart_track: SmartTrack) -> Track:
        track = Track()
        queue = []
        for pitch, sequence in smart_track:
            for interval in sequence:
                if isinstance(interval.metadata, AbstractEvent):
                    queue.append((interval.start, interval.metadata))
                else:
                    velocity = interval.metadata[0]
                    channel = interval.metadata[-1]
                    queue.append((interval.start, NoteOnEvent(tick=interval.start,
                                                              channel=channel,
                                                              data=[pitch, velocity])))
                    queue.append((interval.end, NoteOffEvent(tick=interval.end,
                                                             channel=channel,
                                                             data=[pitch, 0])))
        queue.sort(key=lambda pair: pair[0])
        running_tick = 0
        for pair in queue:
            event = pair[-1]
            new_running_tick = event.tick
            event.tick = event.tick - running_tick
            running_tick = new_running_tick
            track.append(event)
        return track

    def is_successor_of(self, smt: 'SmartMultiTrack') -> bool:
        return super().is_successor_of(smt) and self.semitones == smt.semitones

    def _horizontally_compatible(self, smt: 'SmartMultiTrack') -> bool:
        same_resolution = self.resolution == smt.resolution
        same_atomic_size = self.atomic_size == smt.atomic_size
        same_residual_ratio = self.residual_ratio == smt.residual_ratio
        same_tempo = self.tempo == smt.tempo
        as_many_midi_tracks = len(self.midi_tracks) == len(smt.midi_tracks)
        as_many_smart_tracks = len(self.smart_tracks) == len(smt.smart_tracks)
        return same_resolution \
               and same_atomic_size \
               and same_residual_ratio \
               and same_tempo \
               and as_many_midi_tracks \
               and as_many_smart_tracks

    def split_at_beat(self, beat: int) -> Tuple['SmartMultiTrack', 'SmartMultiTrack']:
        return self.split(beat * self.resolution)

    def split(self, split_pos: int) -> Tuple['SmartMultiTrack', 'SmartMultiTrack']:
        left = SmartMultiTrack(name=self.name,
                               parent=self.parent,
                               initial_start=self.initial_start,
                               resolution=self.resolution,
                               time_sig=self.time_sig,
                               residual_ratio=self.residual_ratio,
                               atomic_size=self.atomic_size)
        right = SmartMultiTrack(name=self.name,
                                parent=self.parent,
                                initial_start=self.initial_start + split_pos,
                                resolution=self.resolution,
                                time_sig=self.time_sig,
                                residual_ratio=self.residual_ratio,
                                atomic_size=self.atomic_size)
        left.tempo = self.tempo
        right.tempo = self.tempo
        left.semitones = self.semitones
        right.semitones = self.semitones
        for midi_track in self.midi_tracks:
            left.add_midi_track(midi_track)
            right.add_midi_track(midi_track)
        for smart_track in self.smart_tracks:
            l, r = smart_track.split(split_pos)
            left.add_smart_track(l)
            right.add_smart_track(r)
        return left, right

    def concat(self, splitable: 'SmartMultiTrack') -> 'SmartMultiTrack':
        res = SmartMultiTrack(name=self.name,
                              parent=self.parent if self.parent == splitable.parent else None,
                              initial_start=self.initial_start,
                              resolution=self.resolution,
                              residual_ratio=self.residual_ratio,
                              atomic_size=self.atomic_size)
        res.tempo = self.tempo
        if len(self.midi_tracks) != len(splitable.midi_tracks):
            raise ValueError(f'cannot concat SmartPianoRolls with different number of '
                             f'pure midi track {len(self.midi_tracks)} vs {len(splitable.midi_tracks)}')
        if len(self.smart_tracks) != len(splitable.smart_tracks):
            raise ValueError(f'cannot concat SmartPianoRolls with different number of '
                             f'smart midi track {len(self.smart_tracks)} vs {len(splitable.smart_tracks)}')

        for midi_track in self.midi_tracks:
            res.add_midi_track(midi_track)

        for i in range(len(self.smart_tracks)):
            res.add_smart_track(self.smart_tracks[i].concat(splitable.smart_tracks[i]))

        return res

    def stack(self, smt: 'SmartMultiTrack') -> 'SmartMultiTrack':
        if self.resolution != smt.resolution:
            raise ValueError(f'cannot stack tracks with different resolutions '
                             f'{self.resolution} ticks  ≠ {smt.resolution} ticks')
        if self.atomic_size != smt.atomic_size \
                or self.residual_ratio != smt.residual_ratio \
                or self.tempo != smt.tempo:
            smt = smt.copy()
            smt.atomic_size = self.atomic_size
            smt.residual_ratio = self.residual_ratio
            smt.tempo = self.tempo

        res = self.copy()
        for s in smt.smart_tracks:
            res.add_smart_track(s)
        return res

    def transpose_by(self, semitones: int) -> 'SmartMultiTrack':
        """
        Create and return a smart piano roll with the same content as this one, except transposed by the
        specified number of semitones.

        :type semitones: the number of semitones to transpose this piano roll by
        :return: the transposed piano-roll, or self if semitones is 0
        """
        if semitones == 0:
            return self
        res = self.copy()
        res.original = self
        res.semitones = semitones
        for smart_track in res.smart_tracks:
            smart_track.transpose(semitones, in_place=True)
        return res

    def ticks_to_beats(self, ticks: int) -> int:
        if ticks % self.resolution != 0:
            self.warning(f'perform rounding operation for tick={ticks}')
        return int(ticks / self.resolution)

    def beats_to_ticks(self, beats: int) -> int:
        return beats * self.resolution

    @staticmethod
    def warning(msg: str) -> None:
        print('WARNING; ' + msg)

    @staticmethod
    def set_duration(track, new_duration):
        if isinstance(track, Track):
            for event in track:
                if isinstance(event, EndOfTrackEvent):
                    event.tick = new_duration
        elif isinstance(track, SmartTrack):
            track.pad_to(new_duration)
        else:
            raise ValueError(f'unknown track type {type(track)}')

    def track_named(self, name: str) -> Optional[SmartTrack]:
        for track in self.smart_tracks:
            if track.name == name:
                return track
        return None

    def track(self, track_idx: int) -> SmartTrack:
        return self.smart_tracks[track_idx]

    def set_smart_all_tracks(self, smart_mode: bool):
        for smart_track in self.smart_tracks:
            self.set_smart_track(smart_track, smart_mode)

    @staticmethod
    def set_smart_track(track: SmartTrack, smart_mode: bool):
        track.smart = smart_mode

    def set_smart_track_named(self, track_name: str, smart_mode: bool):
        self.track_named(track_name).smart = smart_mode

    @staticmethod
    def get_tempo(track):
        if isinstance(track, Track):
            for event in track:
                if isinstance(event, SetTempoEvent):
                    return event.get_bpm()
            # this MIDI track has no tempo information
            return None
        elif isinstance(track, SmartTrack):
            return track.tempo
        else:
            raise ValueError(f'unknown track type {type(track)}')

    def multi_tracks(self, *track_names) -> 'SmartMultiTrack':
        """
        Create a SmartMultiTrack from the specified track names
        """
        raise ValueError("NOT IMPLEMENTED FULLY")
        res = SmartMultiTrack(name=self.name,
                              parent=self.parent,
                              initial_start=self.initial_start,
                              resolution=self.resolution,
                              duration=self.duration,
                              time_sig=self.time_sig)
        for midi_track in self.midi_tracks:
            res.midi_tracks.append(copy(midi_track))
        for smart_track in self.smart_tracks:
            if smart_track.name in track_names:
                res.smart_tracks.append(smart_track.copy())
        return res

    def _put_note_off_events_before_note_on_events(self, raw_midi_track):
        def event_type_rank(event):
            if self.is_note_off(event):
                return 1
            elif self.is_note_on(event):
                return 2
            else:
                return 0

        tick = 0
        start_idx = 0
        end_idx = 0
        to_sort = []
        for ev_idx, event in enumerate(raw_midi_track):
            ev_tick = event.tick
            if ev_tick < tick:
                raise ValueError(f'track events are not sorted at {ev_tick} (event: {event} at index {ev_idx})')
            if ev_tick > tick:
                if start_idx < end_idx:
                    to_sort.append((start_idx, end_idx + 1))
                tick = ev_tick
                start_idx = ev_idx
            else:  # event tick is the current tick
                end_idx = ev_idx
        if start_idx < end_idx:
            to_sort.append((start_idx, end_idx))
        for sidx, eidx in to_sort:
            raw_midi_track[sidx:eidx] = sorted(raw_midi_track[sidx:eidx], key=lambda ev: event_type_rank(ev))

    def has_tempo_event(self):
        for midi_track in self.midi_tracks:
            for ev in midi_track:
                if isinstance(ev, SetTempoEvent):
                    return True
        for smart_track in self.smart_tracks:
            for pitch, seq in smart_track:
                if pitch == -1:
                    for i in seq:
                        if isinstance(i.metadata, SetTempoEvent):
                            return True
        return False

    def has_notes(self):
        for smt in self.smart_tracks:
            if smt.has_notes():
                return True
        return False

    def set_seg_step(self, seg_step):
        for st in self.smart_tracks:
            st.segmentation_step = seg_step

    COUNTER = 0

    def distance(self, smt: 'SmartMultiTrack', n_bins: int = 0) -> float:
        # gbls.logfile.write(f'distance({self}, {smt})\n')
        SmartMultiTrack.COUNTER += 1
        m1 = self.matrix(n_bins=n_bins)
        m2 = smt.matrix(n_bins=n_bins)
        return count_nonzero(logical_xor(m1, m2)) / (m1.shape[0] * m1.shape[1])

    @staticmethod
    def midi_chunks(root: str, chunk_len_in_beats: float) -> Tuple[List[str], List[SmartTrack]]:
        names = []  # type: List[str]
        chunks = []  # type: List[SmartTrack]
        midi_files = [os.path.join(root, f) for f in os.listdir(root) if f.endswith('.mid')]
        for f in midi_files:
            smt = SmartMultiTrack.read(name=f, file_name=f, atomic_size_in_beats=.25, residual_ratio=.125)
            tr = smt.track(0)
            splits = tr.split_every(int(smt.beats_to_ticks(1) * chunk_len_in_beats))  # type: List[SmartTrack]
            for i in range(len(splits)):
                names.append(f + '_' + str(i))
            chunks.extend(splits)
        return names, chunks

    @classmethod
    def similarity_based_transition_cost(cls, s: 'SmartMultiTrack', t: 'SmartMultiTrack', n_bins: int = 0) -> float:
        """
        Compute the cost for transiting from `s` to `t`, based on similarity measures

        :param n_bins:
        :param s: the origin segment
        :param t: the destination segment
        :return: -1 if (s, t) is the actual transition, else, the transition cost
        """
        if t is s.succ:
            return -1
        n_bins = n_bins if n_bins else s.duration
        succ_s = s.succ
        pred_t = t.pred
        if (succ_s is None) and (pred_t is None):
            return 1
        elif succ_s is None:
            return s.distance(pred_t)
        elif pred_t is None:
            return succ_s.distance(t)
        else:
            return min(s.distance(pred_t), succ_s.distance(t))

    def compute_matrix(self, n_bins: int = 0):
        for st in self.smart_tracks:
            st.matrix(n_bins)
