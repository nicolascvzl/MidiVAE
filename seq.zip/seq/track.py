from copy import copy
from typing import Dict, List, Optional, Tuple

import numpy as np
import png
from midi import ControlChangeEvent, EndOfTrackEvent, InstrumentNameEvent, ProgramChangeEvent, SetTempoEvent, \
    TimeSignatureEvent, TrackNameEvent

from seq.interval import Interval
from seq.smart_seq import SmartSequence, Splitable


class SmartTrack(Splitable):
    name: str
    _parent: Optional['SmartTrack']
    _duration: int
    _initial_start: int
    _smart: Optional[bool]
    _atomic_size: Optional[int]
    _residual_ratio: Optional[float]
    _segmentation_step: Optional[int]
    _seq_dict: Dict[int, SmartSequence]
    _tempo: int
    _is_drum: bool
    _matrices: Dict[int, np.ndarray]
    _matrices_mod12: Dict[int, np.ndarray]

    def __init__(self,
                 name: str = 'unnamed track',
                 duration: int = 0,
                 initial_start: int = 0,
                 smart: bool = True,
                 atomic_size: int = None,
                 residual_ratio: float = None):
        self.name = name
        self._parent = None
        self._initial_start = initial_start
        self._duration = duration
        self._smart = smart
        self._atomic_size = atomic_size
        self._residual_ratio = residual_ratio
        self._seq_dict = {}
        self._segmentation_step = None
        self._tempo = None
        self._is_drum = False
        self._matrices = {}
        self._matrices_mod12 = {}

    def __str__(self):
        return f'Track {self.name} of duration {self.duration}'

    def __eq__(self, other):
        if isinstance(self, other.__class__):
            if self.duration != other.duration:
                return False
            if self.segmentation_step != other.segmentation_step:
                return False
            if self.seq_dict != other.seq_dict:
                return False
            return True
        return False

    def __iter__(self):
        for pitch, seq in self.seq_dict.items():
            yield pitch, seq

    def __copy__(self):
        raise TypeError('cannot copy intervals')

    def __deepcopy__(self, memodict):
        raise TypeError('cannot copy intervals')

    def matrix(self, n_bins: int = 0):
        n_bins = self.duration if n_bins == 0 else n_bins
        res = self._matrices[n_bins] if n_bins in self._matrices else self._compute_matrix(n_bins)
        self._matrices[n_bins] = res
        return res

    def matrix_mod12(self, n_bins: int = 0):
        n_bins = self.duration if n_bins == 0 else n_bins
        res = self._matrices_mod12[n_bins] if n_bins in self._matrices_mod12 else self._compute_matrix_mod12(n_bins)
        self._matrices_mod12[n_bins] = res
        return res

    def copy(self):
        res = SmartTrack(self.name, self.duration, self.initial_start)
        res._smart = self.smart
        res._atomic_size = self.atomic_size
        res._residual_ratio = self.residual_ratio
        res._segmentation_step = self._segmentation_step
        res._seq_dict = {}
        # Caution, matrices are NOT copied
        res._matrices = self._matrices.copy()
        res._matrices_mod12 = self._matrices_mod12.copy()
        for k, v in self._seq_dict.items():
            res._seq_dict[k] = v.copy()
        return res

    @property
    def parent(self):
        return self._parent

    @property
    def is_drum(self):
        return self._is_drum

    @parent.setter
    def parent(self, smart_track: 'SmartTrack'):
        self._parent = smart_track

    @property
    def initial_start(self) -> int:
        return self._initial_start

    @initial_start.setter
    def initial_start(self, start: int):
        self._initial_start = start

    @property
    def duration(self) -> int:
        return self._duration

    @property
    def empty(self) -> bool:
        for pitch, seq in self:
            if pitch == -1:
                continue
            if not seq.empty:
                return False
        return True

    @property
    def tempo(self) -> int:
        return self._tempo

    @tempo.setter
    def tempo(self, new_tempo):
        if -1 not in self.seq_dict:
            raise ValueError(f'cannot change tempo of {self} (no midi event sequence)')
        for event in self.seq_dict[-1]:
            if isinstance(event.metadata, SetTempoEvent):
                event.metadata.set_bpm(new_tempo)
                self._tempo = new_tempo
                return

        tempo_ev = SetTempoEvent()
        tempo_ev.set_bpm(new_tempo)
        tempo_ev.tick = 0
        self.seq_dict[-1].insert(1, Interval(0, 0, tempo_ev))

    @property
    def segmentation_step(self) -> int:
        return self._segmentation_step

    @segmentation_step.setter
    def segmentation_step(self, seg_step: int):
        # if self.segmentation_step is not None:
        #     raise ValueError(f"cannot change a track's segmentation step ({self.segmentation_step})")
        for pitch, seq in self:
            seq.segmentation_step = seg_step
        self._segmentation_step = seg_step

    @property
    def seq_dict(self):
        return self._seq_dict

    @property
    def atomic_size(self) -> int:
        return self._atomic_size

    @atomic_size.setter
    def atomic_size(self, v):
        self._atomic_size = v
        for pitch, seq in self._seq_dict.items():
            seq.atomic_size = v

    @property
    def residual_ratio(self) -> float:
        return self._residual_ratio

    @residual_ratio.setter
    def residual_ratio(self, v):
        self._residual_ratio = v
        for pitch, seq in self._seq_dict.items():
            seq.residual_ratio = v

    @property
    def smart(self) -> bool:
        return self._smart

    @smart.setter
    def smart(self, b):
        self._smart = b
        for pitch, seq in self._seq_dict.items():
            seq.smart = b

    def put_sequence(self, key: int, seq: SmartSequence, overwrite: bool = False):
        if seq.duration != self.duration:
            raise ValueError(f'cannot put sequence of duration {seq.duration} in track of duration {self.duration}')
        if not overwrite and self.has_key(key):
            raise ValueError(f'track already has a sequence at key {key}, set "overwrite" parameter to "True"')

        if self.has_sequences():
            if seq.segmentation_step != self.segmentation_step:
                raise ValueError(f'cannot put sequence with segmentation step {seq.segmentation_step} '
                                 f'in track with sequence with step {self.segmentation_step}')

        if self.smart is None:
            self._smart = seq.smart
        else:
            if self.smart != seq.smart:
                raise ValueError(f'cannot put {"SMART" if seq.smart else "NON-SMART"} sequence '
                                 f'in {"SMART" if self.smart else "NON-SMART"} track')

        if self.atomic_size is None:
            self._atomic_size = seq.atomic_size
        else:
            if self.atomic_size != seq.atomic_size:
                raise ValueError(f'cannot put sequence with atomic size {seq.atomic_size} '
                                 f'in track with atomic size {self.atomic_size}')

        if self.residual_ratio is None:
            self._residual_ratio = seq.residual_ratio
        else:
            if self.residual_ratio != seq.residual_ratio:
                raise ValueError(f'cannot put sequence with residual ratio {seq.residual_ratio} '
                                 f'in track with residual ratio {self.residual_ratio}')

        self.invalidate_matrices()
        self._seq_dict.update({key: seq})
        self._segmentation_step = seq.segmentation_step

    def sequence(self, key: int) -> SmartSequence:
        """

        :param key:
        :return: the sequence at the specified key or a new, empty sequence of this track's duration
        """
        if self.has_key(key):
            return self._seq_dict[key]

        return SmartSequence(duration=self.duration,
                             initial_start=self.initial_start,
                             smart=self.smart,
                             atomic_size=self.atomic_size,
                             residual_ratio=self.residual_ratio,
                             segmentation_step=self.segmentation_step)

    def has_key(self, key: int) -> bool:
        return key in self._seq_dict

    def has_sequences(self):
        return self._seq_dict

    def split(self, split_pos: int) -> Tuple['SmartTrack', 'SmartTrack']:
        if self.segmentation_step is None:
            raise ValueError(f'cannot split a track with no segmentation step specified')
        if split_pos % self.segmentation_step != 0:
            raise ValueError(f'cannot split at position {split_pos}, must be a multiple of {self.segmentation_step}')

        left_track = SmartTrack(self.name, split_pos, self.initial_start, atomic_size=self.atomic_size,
                                residual_ratio=self.residual_ratio)
        right_track = SmartTrack(self.name, self.duration - split_pos, split_pos, atomic_size=self.atomic_size,
                                 residual_ratio=self.residual_ratio)

        for key, seq in self:
            if key == -1:
                left_seq, right_seq = self._zero_time_event_split(seq, split_pos)
            else:
                left_seq, right_seq = seq.split(split_pos)
            left_track.put_sequence(key, left_seq)
            right_track.put_sequence(key, right_seq)

        return left_track, right_track

    def concat(self, track: 'SmartTrack') -> 'SmartTrack':
        if self.segmentation_step is None:
            raise ValueError(f'cannot concat a track with no segmentation step specified')
        if self.segmentation_step != track.segmentation_step:
            raise ValueError(f'cannot concatenate tracks with different segmentation steps '
                             f'{self.segmentation_step} ≠ {track.segmentation_step}')

        res = SmartTrack(self.name, self.duration + track.duration, self.initial_start,
                         atomic_size=self.atomic_size,
                         residual_ratio=self.residual_ratio)
        for key in self._seq_dict.keys() | track._seq_dict.keys():
            if key == -1:
                res.put_sequence(key, self._zero_time_event_concat(self.sequence(key), track.sequence(key)))
            else:
                res.put_sequence(key, self.sequence(key).concat(track.sequence(key)))

        return res

    def transpose(self, semitones: int, in_place: bool = False):
        res = self if in_place else self.copy()
        res.transpose_matrices(semitones, in_place)
        res._matrices_mod12.clear()
        if not in_place:
            res.parent = self.parent
        new_seq_dict = {}
        for pitch, seq in self:
            if pitch == -1:
                new_seq_dict[pitch] = seq
            else:
                if pitch + semitones < 0 or pitch + semitones > 127:
                    raise ValueError(f'cannot transpose {self} by {semitones} semitones'
                                     f' ({pitch+semitones} exceeds MIDI pitch range)')
                new_seq_dict[pitch + semitones] = seq
        res._seq_dict = new_seq_dict
        return res

    def transpose_matrices(self, semitones: int, in_place: bool) -> None:
        if semitones == 0:
            return
        for n_steps in self._matrices:
            m = self._matrices[n_steps] if in_place else copy(self._matrices[n_steps])
            if semitones < 0:
                m[127 - semitones + 1:128, :] = 0
                np.roll(m, -semitones, axis=0)
            else:
                m[0:semitones + 1, :] = 0
                np.roll(m, -semitones, axis=0)

    @staticmethod
    def _zero_time_event_split(seq: SmartSequence, split_pos: int) -> Tuple[SmartSequence, SmartSequence]:
        """
        Split tracks with
        :param seq:
        :param split_pos:
        :return:
        """
        left, right = seq.empty_copy(split_pos), seq.empty_copy(seq.duration - split_pos)
        for interval in seq:
            event = interval.metadata
            tick = interval.start
            if isinstance(event, (TrackNameEvent, ControlChangeEvent, ProgramChangeEvent, SetTempoEvent)):
                if tick != 0 and isinstance(event, (TrackNameEvent, SetTempoEvent)):
                    raise ValueError(f'sequence with {type(event)} at nonzero position {tick}')
                if tick != 0 and isinstance(event, (ControlChangeEvent, ProgramChangeEvent)):
                    # ignores Program and Control changes not at the beginning of the track
                    pass
                else:
                    left.append(interval)
                    right.append(interval)
            elif isinstance(event, EndOfTrackEvent):
                if tick != seq.duration:
                    raise ValueError(f'sequence with non-ending EndOfTrackEvent at position {tick}')
                left.append(Interval(split_pos, split_pos, metadata=event))
                event_copy = copy(event)
                event_copy.tick = right.duration
                right.append(Interval(right.duration, right.duration, metadata=event_copy))
            else:
                if tick <= split_pos:
                    left.append(interval)
                else:
                    new_interval = interval.translated_copy_by(-split_pos)
                    new_interval.metadata = copy(interval.metadata)
                    new_interval.metadata.tick = new_interval.start
                    right.append(new_interval)
        return left, right

    @staticmethod
    def _zero_time_event_concat(left: SmartSequence, right: SmartSequence) -> SmartSequence:
        res = left.empty_copy(left.duration + right.duration)
        for interval in left:
            event = interval.metadata
            if isinstance(event, (TrackNameEvent, SetTempoEvent)):
                if interval.start != 0:
                    raise ValueError(f'sequence with {type(event)} at nonzero position {interval.start}')
                res.append(interval)
            elif isinstance(event, EndOfTrackEvent):
                pass
            elif isinstance(event, (InstrumentNameEvent, ControlChangeEvent, TimeSignatureEvent)):
                if interval.start != 0:
                    raise ValueError(f'sequence with InstrumentNameEvent at nonzero position {interval.start}')
                res.append(interval)
            else:
                raise ValueError('TODO, method not implemented (should be fairly easy to do)')
        for interval in right:
            event = interval.metadata
            if isinstance(event, (TrackNameEvent, SetTempoEvent)):
                pass
            elif isinstance(event, EndOfTrackEvent):
                if interval.start != right.duration:
                    raise ValueError(f'sequence with non-ending EndOfTrackEvent at position {interval.start}')
                event_copy = copy(event)
                event_copy.tick = res.duration
                res.append(Interval(res.duration, res.duration, metadata=event_copy))
            elif isinstance(event, (InstrumentNameEvent, ControlChangeEvent, TimeSignatureEvent)):
                pass
            else:
                raise ValueError(f'unknown event {event}, method not implemented (should be fairly easy to do)')
        return res

    def pad_to(self, new_duration):
        self._duration = new_duration
        for _, seq in self:
            seq.pad_to(new_duration)

    def has_notes(self) -> bool:
        for pitch, seq in self:
            if pitch == -1:
                continue
            if seq.has_intervals():
                return True
        return False

    def _compute_matrix(self, n_bins: int) -> np.ndarray:
        return self.as_boolean_matrix(n_bins=n_bins)

    def _compute_matrix_mod12(self, n_bins: int) -> np.ndarray:
        m = self.matrix(n_bins)
        m12 = np.zeros((12, n_bins), dtype=bool)
        for i in range(128):
            m12[i % 12, :] = np.logical_or(m[i, :], m12[i % 12, :])
        return m12

    def invalidate_matrices(self):
        self._matrices.clear()
        self._matrices_mod12.clear()

    def as_boolean_matrix(self, n_bins: int = 0):
        n_bins = self.duration if n_bins == 0 else n_bins
        time_step, m = divmod(self.duration, n_bins)
        if m is not 0:
            raise ValueError(f'duration {self.duration} is not a multiple of number of steps {n_bins}')
        n_bins, mod = divmod(self.duration, time_step)
        if mod > 0:
            n_bins += 1
            self.pad_to(n_bins * time_step)
        matrix = np.zeros((128, n_bins), dtype=bool)
        for pitch, seq in self:
            if pitch == -1:
                continue
            for event in seq:
                s = event.start
                e = event.end
                d1, m1 = divmod(s, time_step)
                d2, m2 = divmod(e, time_step)
                matrix[pitch, d1:min(n_bins, (d2 + (1 if m2 > 0 else 0)) + 1)] = 1
        return matrix

    def save_as_png(self, n_steps: int, png_file_name: str):
        m = self.matrix(n_steps)
        img = png.from_array(m[::-1], 'L')
        img.save(png_file_name)

    @classmethod
    def png_to_array(cls, png_file_name: str) -> List[List[int]]:
        res = []
        with open(png_file_name, 'rb') as f:
            r = png.Reader(f)
            _, _, l, _ = r.read()
            for x in l:
                res.append(list(x))
        return res

    @classmethod
    def png_to_smart_track(cls,
                           png_file_name: str,
                           track_name: str,
                           track_duration: int,
                           threshold: int = 0) -> 'SmartTrack':
        res = SmartTrack(name=track_name, duration=track_duration)
        arr = cls.png_to_array(png_file_name)
        d, m = divmod(track_duration, len(arr[0]))
        if m is not 0:
            raise ValueError(
                f'target track duration {track_duration} is not a multiple of png file width {len(arr[0])}')
        for pitch, row in enumerate(arr):
            seq = SmartSequence(duration=track_duration)
            crt_interval = None
            for i, v in enumerate(row):
                if v <= threshold:
                    if crt_interval:
                        crt_interval.end += d
                    else:
                        crt_interval = Interval(start=d * i, end=d * (i + 1))
                else:
                    if crt_interval:
                        seq.append(crt_interval)
                        crt_interval = None
            if crt_interval:
                seq.append(crt_interval)
            res.put_sequence(pitch, seq)
        return res
