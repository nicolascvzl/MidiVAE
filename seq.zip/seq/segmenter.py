from abc import ABC, abstractmethod
from typing import List

from seq.smart_seq import Splitable


class Segmenter(ABC):
    @abstractmethod
    def __iter__(self) -> Splitable:
        pass


class FixedStepSegmenter(Segmenter):
    """
    Basic segmentation object which segments a splitable roll equal-duration splitable objects
    """
    _split_step: int
    _splitable: Splitable

    def __init__(self, splitable: Splitable, split_step: int):
        if splitable.duration % split_step != 0:
            raise ValueError(f'cannot split by {split_step}-steps a Splitable object '
                             f'with odd duration {splitable.duration}')
        self._fixed_step = split_step
        self._splitable = splitable

    def __iter__(self):
        return self.segments().__iter__()

    def segments(self) -> List[Splitable]:
        d, _ = divmod(self.splitable.duration, self.split_step)
        res = [self.splitable] * d
        head = self.splitable
        i = d - 1
        while i > 0:
            head, tail = head.split(i * self.split_step)
            res[i] = tail
            i -= 1
        res[0] = head
        return res

    @property
    def split_step(self) -> int:
        return self._fixed_step

    @property
    def splitable(self):
        return self._splitable
