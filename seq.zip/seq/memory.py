class Memory(object):
    """
    Stores the memory of a sequence at a specific positions in time. A `Memory` stores seven values.
    """
    _ll: int
    _lr: int
    _rl: int
    _rr: int
    _lb: bool
    _rb: bool
    _lr_is_residual: bool
    _rl_is_residual: bool
    _l_metadata: object
    _r_metadata: object

    def __init__(self,
                 ll=0,
                 lr=0,
                 rl=0,
                 rr=0,
                 lb=False,
                 rb=False,
                 lr_is_residual=False,
                 rl_is_residual=False,
                 l_metadata=None,
                 r_metadata=None):
        """
        Sets the four values.

        :param ll: the **left**-side memory, which is kept with the **left** sequence upon splitting
        :param lr: the **right**-side memory, which is kept with the **left** sequence upon splitting
        :param rl: the **left**-side memory, which is kept with the **right** sequence upon splitting
        :param rr: the **right**-side memory, which is kept with the **right** sequence upon splitting
        """
        self._ll = ll
        self._lr = lr
        self._rl = rl
        self._rr = rr
        self._lb = lb
        self._rb = rb
        self._lr_is_residual = lr_is_residual
        self._rl_is_residual = rl_is_residual
        self._l_metadata = l_metadata
        self._r_metadata = r_metadata

    def __copy__(self):
        raise TypeError('should not be called')

    def __str__(self):
        return f'<{self.ll},{self.lr}|{self.rl},{self.rr},{self.lb},{self.rb}>'

    def copy(self):
        return Memory(self.ll,
                      self.lr,
                      self.rl,
                      self.rr,
                      self.lb,
                      self.rb,
                      self._lr_is_residual,
                      self._rl_is_residual,
                      self.l_metadata,
                      self.r_metadata)

    @property
    def ll(self):
        return self._ll

    @ll.setter
    def ll(self, duration: int):
        self._ll = duration

    @property
    def lr(self):
        return self._lr

    @lr.setter
    def lr(self, duration):
        self._lr = duration

    @property
    def rl(self):
        return self._rl

    @rl.setter
    def rl(self, duration: int):
        self._rl = duration

    @property
    def rr(self):
        return self._rr

    @rr.setter
    def rr(self, duration: int):
        self._rr = duration

    @property
    def lb(self):
        return self._lb

    @lb.setter
    def lb(self, b: bool):
        self._lb = b

    @property
    def rb(self):
        return self._rb

    @rb.setter
    def rb(self, b: bool):
        self._rb = b

    @property
    def lr_is_residual(self):
        return self._lr_is_residual

    @lr_is_residual.setter
    def lr_is_residual(self, b: bool):
        self._lr_is_residual = b

    @property
    def rl_is_residual(self):
        return self._rl_is_residual

    @rl_is_residual.setter
    def rl_is_residual(self, b: bool):
        self._rl_is_residual = b

    @property
    def l_metadata(self):
        return self._l_metadata

    @l_metadata.setter
    def l_metadata(self, md: object):
        self._l_metadata = md

    @property
    def r_metadata(self):
        return self._r_metadata

    @r_metadata.setter
    def r_metadata(self, md: object):
        self._r_metadata = md
