from typing import Dict, Tuple

from seq.smart_multi_track import SmartMultiTrack


class PitchHistogram(object):
    """
    A pitch histogram for a piano roll, possibly modulo 12
    """

    def __init__(self, smt: SmartMultiTrack, mod12: bool = True):
        self._histogram_dict = {}
        self.mod12 = mod12
        for smart_track in smt.smart_tracks:
            for pitch, seq in smart_track:
                if pitch == -1:
                    continue
                for interval in smart_track.sequence(pitch):
                    p = pitch % 12 if mod12 else pitch
                    if p in self._histogram_dict:
                        self._histogram_dict[p] += interval.duration
                    else:
                        self._histogram_dict[p] = interval.duration
        self.histogram = sorted(self._histogram_dict.items())

    def __str__(self):
        s = f''
        for pitch_dur in self.histogram:
            s += f'({pitch_dur[0]}: {pitch_dur[1]:.2f})\t'
        return s.strip()

    def key_set(self):
        return set(self._histogram_dict.keys())

    def has_same_keys_as(self, histogram: 'PitchHistogram') -> bool:
        if self.mod12 != histogram.mod12:
            raise ValueError(f'cannot compare a modulo 12 histogram with a non-modulo 12 one')
        return self._histogram_dict.keys() == histogram._histogram_dict.keys()

    def _differences_with(self, histogram: 'PitchHistogram') -> Tuple[float, float, float, float]:
        if self.mod12 != histogram.mod12:
            raise ValueError(f'cannot compare a modulo 12 histogram with a non-modulo 12 one')
        common, new, missing = 0, 0, 0
        self_keys = self.key_set()
        histogram_keys = histogram.key_set()
        common_keys = self_keys.intersection(histogram_keys)
        new_keys = histogram_keys.difference(self_keys)
        missing_keys = self_keys.difference(histogram_keys)
        same, diff = 0, 0
        for key in common_keys:
            d1 = self._histogram_dict[key]
            d2 = histogram._histogram_dict[key]
            same += min(d1, d2)
            diff += abs(d1 - d2)
        for new_key in new_keys:
            new += histogram._histogram_dict[new_key]
        for missing_key in missing_keys:
            missing += self._histogram_dict[missing_key]
        return same, (same / (same + diff)) if same + diff else 0, new, missing

    def similarity(self,
                   histogram: 'PitchHistogram',
                   foreign_notes_penalty_weight: float = 1,
                   missing_notes_penalty_weight: float = 0.5) -> float:
        """
        Compute and return a similarity between pitch histograms, taking into account common notes and their
        durations, as well as new notes (i.e., notes present in the input histogram that aren't present in this
        histogram) and missing notes (i.e., notes present in this histogram and missing in the input histogram)

        :param histogram: another pitch histogram
        :param foreign_notes_penalty_weight: the weight for notes that are in this histogram and not in the parameter
        :param missing_notes_penalty_weight: the weight for notes of this histogram missing in the parameter
        :return: a tuple with the duration of common notes, that of new notes, and that of missing notes
        """

        assert self.mod12 == histogram.mod12

        if self.empty() and histogram.empty():
            return 1
        elif self.empty():
            return 0
        elif histogram.empty():
            return 0

        c, d, n, m = self._differences_with(histogram)
        res = d * c / (c + foreign_notes_penalty_weight * n + missing_notes_penalty_weight * m)
        if not 0 <= res <= 1:
            raise ValueError(f'found piano roll similarity {res} between'
                             f'\n\t{self}'
                             f'\n\t{histogram}'
                             f'should satisfy 0 ≤ {res} ≤ 1')
        return res

    def empty(self):
        return len(self.key_set()) == 0


class SlicedPitchHistogram(object):
    """
    A pitch histogram for a piano roll, possibly modulo 12
    """

    def __init__(self, smt: SmartMultiTrack, n_bins: int = 1, mod12: bool = True):
        self.n_bins = n_bins
        self._bin_len = int(smt.duration / n_bins)
        self._histogram_dicts = []
        for i in range(self.n_bins):
            self._histogram_dicts.append({})
        self._pitches = set()
        self.mod12 = mod12
        for smart_track in smt.smart_tracks:
            for pitch, seq in smart_track:
                if pitch == -1:
                    continue
                for interval in smart_track.sequence(pitch):
                    p = pitch % 12 if mod12 else pitch
                    self._pitches.add(p)
                    if interval.start == interval.end:
                        # special case for zero-duration pitch events
                        continue
                    sd, sm = divmod(interval.start, self._bin_len)
                    ed, em = divmod(interval.end, self._bin_len)
                    if em == 0:
                        ed -= 1
                        em = self._bin_len
                    if ed == sd:
                        if p in self._histogram_dicts[sd]:
                            self._histogram_dicts[sd][p] += em - sm
                        else:
                            self._histogram_dicts[sd][p] = em - sm
                    else:
                        if p in self._histogram_dicts[sd]:
                            self._histogram_dicts[sd][p] += self._bin_len - sm
                        else:
                            self._histogram_dicts[sd][p] = self._bin_len - sm
                        if p in self._histogram_dicts[ed]:
                            self._histogram_dicts[ed][p] += em
                        else:
                            self._histogram_dicts[ed][p] = em
                        for d in range(sd + 1, ed):
                            if p in self._histogram_dicts[d]:
                                self._histogram_dicts[d][p] += self._bin_len
                            else:
                                self._histogram_dicts[d][p] = self._bin_len
        self.histograms = []
        for i in range(self.n_bins):
            self.histograms.append(sorted(self._histogram_dicts[i].items()))

    def __str__(self):
        s = f''
        for i, histogram in enumerate(self.histograms):
            s += f'Slice #{i}: '
            for pitch_dur in histogram:
                s += f'({pitch_dur[0]}: {pitch_dur[1]:.2f})\t'
            s += f'\n'
        return s.strip()

    def key_set(self):
        return set(self._pitches)

    def has_same_keys_as(self, histogram: 'SlicedPitchHistogram') -> bool:
        if self.mod12 != histogram.mod12:
            raise ValueError(f'cannot compare a modulo 12 histogram with a non-modulo 12 one')
        return self.key_set() == histogram.key_set()

    def _differences_between(self, h1: Dict[int, float], h2: Dict[int, float]) -> Tuple[float, float, float, float]:
        common, new, missing = 0, 0, 0
        self_keys = set(h1.keys())
        histogram_keys = set(h2.keys())
        common_keys = self_keys.intersection(histogram_keys)
        new_keys = histogram_keys.difference(self_keys)
        missing_keys = self_keys.difference(histogram_keys)
        same, diff = 0, 0
        for key in common_keys:
            d1 = h1[key]
            d2 = h2[key]
            same += min(d1, d2)
            diff += abs(d1 - d2)
        for new_key in new_keys:
            new += h2[new_key]
        for missing_key in missing_keys:
            missing += h1[missing_key]
        return same, (same / (same + diff)) if same + diff else 0, new, missing

    def similarity(self,
                   histogram: 'SlicedPitchHistogram',
                   foreign_notes_penalty_weight: float = 10,
                   missing_notes_penalty_weight: float = 10) -> float:
        """
        Compute and return a similarity between pitch histograms, taking into account common notes and their
        durations, as well as new notes (i.e., notes present in the input histogram that aren't present in this
        histogram) and missing notes (i.e., notes present in this histogram and missing in the input histogram)

        :param histogram: another pitch histogram
        :param foreign_notes_penalty_weight: the weight for notes that are in this histogram and not in the parameter
        :param missing_notes_penalty_weight: the weight for notes of this histogram missing in the parameter
        :return: a tuple with the duration of common notes, that of new notes, and that of missing notes
        """

        assert self.mod12 == histogram.mod12
        assert self.n_bins == histogram.n_bins

        if self.empty() and histogram.empty():
            return 1
        elif self.empty():
            return 0
        elif histogram.empty():
            return 0

        c = d = n = m = 0
        for i in range(self.n_bins):
            h1 = self._histogram_dicts[i]
            h2 = histogram._histogram_dicts[i]
            _c, _d, _n, _m = self._differences_between(h1, h2)
            c += _c
            d += _d
            n += _n
            m += _m
        c /= self.n_bins
        d /= self.n_bins
        n /= self.n_bins
        m /= self.n_bins
        res = d * c / (c + foreign_notes_penalty_weight * n + missing_notes_penalty_weight * m)
        if not 0 <= res <= 1:
            raise ValueError(f'found piano roll similarity {res} between'
                             f'\n\t{self}'
                             f'\n\t{histogram}'
                             f'should satisfy 0 ≤ {res} ≤ 1')
        return res

    def empty(self):
        return len(self.key_set()) == 0


class RhythmHistogram(object):
    """
    A rhythm histogram for a piano roll, possibly
    """

    def __init__(self, smart_multi_track: SmartMultiTrack, n_bins: int = 4):
        self.histogram = [0] * n_bins
        self.n_bins = n_bins
        self.bin_len = int(smart_multi_track.duration / n_bins)
        for smart_track in smart_multi_track.smart_tracks:
            for pitch, seq in smart_track:
                if pitch == -1:
                    continue
                for interval in smart_track.sequence(pitch):
                    d, _ = divmod(interval.start, self.bin_len)
                    self.histogram[d] += 1

    def __str__(self):
        return f'Rhythm Histogram: {self.histogram}'

    def times(self, factor: float):
        """
        In place multiplication by a floating point number

        :param factor:
        :return:
        """
        if factor == 1:
            return self
        for i in range(self.n_bins):
            self.histogram[i] *= factor
        return self

    def similarity(self, histogram: 'RhythmHistogram') -> float:

        if self.n_bins != histogram.n_bins:
            raise ValueError(f'cannot compare histograms with different numbers of bins '
                             f'{self.n_bins} ≠ {histogram.n_bins}')

        if self.empty() and histogram.empty():
            return 1

        diff = 0
        for i in range(self.n_bins):
            diff += abs(self.histogram[i] - histogram.histogram[i])
        diff /= sum(self.histogram) + sum(histogram.histogram)
        return 1 - diff

    def empty(self):
        return self.num_notes() == 0

    def num_notes(self):
        return sum(self.histogram)
