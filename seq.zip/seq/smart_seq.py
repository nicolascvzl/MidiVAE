from abc import ABC, abstractmethod
from typing import Dict, Iterable, Iterator, List, Optional, Tuple

import matplotlib.pyplot as plt
from matplotlib import patches
from midi import EndOfTrackEvent
from mpl_toolkits.axisartist import SubplotZero
from tqdm import tqdm

from seq.interval import Interval
from seq.lists import GenericList
from seq.memory import Memory


class Splitable(ABC):
    @abstractmethod
    def copy(self):
        pass

    @property
    @abstractmethod
    def parent(self) -> 'Splitable':
        pass

    @parent.setter
    @abstractmethod
    def parent(self, splitable: 'Splitable'):
        pass

    @property
    @abstractmethod
    def initial_start(self) -> int:
        pass

    @initial_start.setter
    @abstractmethod
    def initial_start(self, start: int):
        pass

    @abstractmethod
    def split(self, split_pos: int) -> Tuple['Splitable', 'Splitable']:
        pass

    @abstractmethod
    def concat(self, splitable: 'Splitable') -> 'Splitable':
        pass

    @property
    @abstractmethod
    def duration(self) -> int:
        pass

    @property
    @abstractmethod
    def smart(self) -> bool:
        pass

    @property
    @abstractmethod
    def empty(self) -> bool:
        pass

    @smart.setter
    @abstractmethod
    def smart(self, b: bool):
        pass

    @property
    @abstractmethod
    def atomic_size(self) -> int:
        pass

    @property
    @abstractmethod
    def residual_ratio(self) -> float:
        pass

    def is_successor_of(self, splitable: 'Splitable') -> bool:
        return self.parent is splitable.parent \
               and splitable.initial_start + splitable.duration == self.initial_start

    def is_zero_duration(self) -> bool:
        return self.duration == 0

    def halve(self):
        if self.duration % 2 != 0:
            raise ValueError(f'cannot half a Splitable object with odd duration {self.duration}')
        return self.split(int(self.duration / 2))

    def split_every(self, step: int,
                    start: int = 0,
                    end: int = 0,
                    show_progress: bool = False) -> List['Splitable']:
        if self.duration % step != 0:
            raise ValueError(f'cannot split by {step}-steps a Splitable object '
                             f'with odd duration {self.duration}')

        res = []
        if end == 0:
            end = self.duration
        if start % step != 0:
            raise ValueError(f'{start} is not a multiple of {step}')
        if end % step != 0:
            raise ValueError(f'{end} is not a multiple of {step}')

        _, rem = self.split(start)
        rng = range(start + step, end + step, step)
        for _ in (tqdm(rng) if show_progress else rng):
            left, rem = rem.split(step)
            res.append(left)
        return res

    @classmethod
    def concat_all(cls, splitables: Iterable['Splitable'], show_tqdm: bool = False) -> Optional['Splitable']:
        if not splitables:
            return None
        res = None
        for splitable in (tqdm(splitables) if show_tqdm else splitables):
            if res is None:
                res = splitable.copy()
            else:
                res = res.concat(splitable.copy())
        return res


class SmartSequence(Splitable):
    _duration: int
    _smart: bool
    _atomic_size: int
    _residual_ratio: float
    _segmentation_step: int
    _intervals: GenericList[Interval]
    _residues: Dict[int, Optional[Memory]]

    def __init__(self,
                 duration: int,
                 initial_start: int = 0,
                 smart: bool = True,
                 atomic_size: int = 1,
                 residual_ratio: float = 0.25,
                 segmentation_step: int = 10):
        if duration < 0:
            raise ValueError(f'negative sequence duration {duration}')
        if atomic_size > segmentation_step:
            raise ValueError(f'cannot make sequence with atomic size {atomic_size} '
                             f'greater than segmentation step {segmentation_step}')
        if duration % segmentation_step != 0:
            raise ValueError(f'sequence of duration {duration} '
                             f'cannot be segmented every {segmentation_step}')

        self._parent = None
        self._initial_start = initial_start
        self._duration = duration
        self._smart = smart
        self._atomic_size = atomic_size
        self._residual_ratio = residual_ratio
        self._segmentation_step = segmentation_step
        self._intervals = GenericList()
        self._residues = {}

    def __eq__(self, other):
        """
        This equality test does not take residues into account.

        :param other: another sequence to compare this one with
        :return:
        """
        if isinstance(self, other.__class__):
            if self.duration != other.duration:
                return False
            if self.atomic_size != other.atomic_size:
                return False
            if self.residual_ratio != other.residual_ratio:
                return False
            if self.segmentation_step != other.segmentation_step:
                return False
            if self._intervals != other._intervals:
                return False
            return True
        return False

    def __repr__(self):
        return f'{self.duration}; ' \
               f'{self.atomic_size}; ' \
               f'{self.residual_ratio}; ' \
               f'{self.segmentation_step}; ' \
               f'[' + ', '.join(map(str, self._intervals)) + ']'

    def __str__(self):
        return repr(self)

    def __iter__(self) -> Iterator[Interval]:
        return self._intervals.__iter__()

    def __getitem__(self, item):
        return self._intervals[0]

    def __copy__(self):
        raise TypeError('cannot copy intervals')

    def copy(self):
        res = SmartSequence(self.duration,
                            self.initial_start,
                            self.smart,
                            self.atomic_size,
                            self.residual_ratio,
                            self.segmentation_step)
        for interval in self:
            res.append(interval.copy())

        for pos in self._residues:
            res._residues[pos] = self._residues[pos].copy()

        return res

    def __deepcopy__(self, memodict):
        raise TypeError('cannot copy intervals')

    def empty_copy(self, duration: int):
        return SmartSequence(duration=duration,
                             smart=self.smart,
                             atomic_size=self.atomic_size,
                             residual_ratio=self.residual_ratio,
                             segmentation_step=self.segmentation_step)

    @property
    def parent(self):
        return self._parent

    @parent.setter
    def parent(self, smart_seq: 'SmartSequence'):
        self._parent = smart_seq

    @property
    def initial_start(self) -> int:
        return self._initial_start

    @initial_start.setter
    def initial_start(self, start: int):
        self._initial_start = start

    def _get_residue(self, t: int) -> Optional[Memory]:
        if t not in self._residues:
            self._compute_residue(t)
        return self._residues[t]

    @property
    def atomic_size(self) -> int:
        return self._atomic_size

    @atomic_size.setter
    def atomic_size(self, atomic_size: int):
        self._atomic_size = atomic_size

    @property
    def residual_ratio(self) -> float:
        return self._residual_ratio

    @residual_ratio.setter
    def residual_ratio(self, residual_ratio: float):
        self._residual_ratio = residual_ratio

    @property
    def segmentation_step(self) -> int:
        return self._segmentation_step

    @segmentation_step.setter
    def segmentation_step(self, segmentation_step: int):
        self._segmentation_step = segmentation_step

    @property
    def duration(self) -> int:
        return self._duration

    @property
    def smart(self) -> bool:
        return self._smart

    @smart.setter
    def smart(self, b: bool):
        self._smart = b

    @property
    def empty(self) -> bool:
        return not self.has_intervals()

    def has_intervals(self) -> bool:
        return not self._intervals.empty

    def pad_to(self, new_duration):
        if new_duration % self.segmentation_step != 0:
            raise ValueError(f'cannot pad to {new_duration}, should a multiple of {self.segmentation_step}')
        # moves the EndOfTrack to the new ending position
        self._duration = new_duration
        if isinstance(self._intervals.tail.metadata, EndOfTrackEvent):
            self._intervals.tail.start = new_duration
            self._intervals.tail.end = new_duration
            self._intervals.tail.metadata.tick = new_duration

    def _append(self, interval: Interval) -> None:
        self._intervals.append(interval)

    def append(self, interval: Interval) -> None:
        if interval.end > self.duration:
            raise ValueError(f'interval {interval} exceeds sequence duration {self.duration}')
        if self.last_interval() and interval.start < self.last_interval().end:
            raise ValueError(f'interval {interval} not after last current interval {self.last_interval()}')

        self._append(interval)

    def insert(self, idx: int, interval: Interval) -> None:
        if interval.end > self.duration:
            raise ValueError(f'interval {interval} exceeds sequence duration {self.duration}')
        if len(self._intervals) < idx:
            raise ValueError(f'cannot insert at position {idx}, sequence has {len(self._intervals)} items')

        self._intervals.insert(idx, interval)

    def _interval_at(self, t: int) -> Tuple[Optional[Interval], Optional[int]]:
        for idx, interval in enumerate(self._intervals):
            if interval.start > t:
                return None, None
            if interval.end >= t:
                return interval, idx

        return None, None

    def _compute_residue(self, t: int):
        interval, idx = self._interval_at(t)
        self._residues[t] = mem = Memory()
        if interval is None:
            return
        before, after = interval.split(t)
        metadata = interval.metadata

        if t == 0:
            if interval.start == 0:
                mem.rr = interval.duration
                mem.rb = True
                mem.r_metadata = metadata
        elif t == self.duration:
            if interval.end == t:
                mem.ll = interval.duration
                mem.lb = True
                mem.l_metadata = metadata
        else:
            if before > 0 and after > 0:
                mem.ll = before
                mem.rl = before
                mem.lr = after
                mem.rr = after
                mem.lr_is_residual = self.is_residual(after, before + after)
                mem.rl_is_residual = self.is_residual(before, before + after)
                mem.l_metadata = mem.r_metadata = metadata
            elif interval.end == t \
                    and (self._intervals[idx + 1].start == t if len(self._intervals) > idx + 1 else False):
                mem.ll = interval.duration
                mem.l_metadata = metadata
                mem.rr = self._intervals[idx + 1].duration
                mem.r_metadata = self._intervals[idx + 1].metadata
                mem.lb = True
                mem.rb = True
            elif interval.end == t:
                mem.ll = interval.duration
                mem.lb = True
                mem.l_metadata = metadata
            elif interval.start == t:
                mem.rr = interval.duration
                mem.rb = True
                mem.r_metadata = metadata

    def segmentation_positions(self, start: int, end: int):
        fd, fm = divmod(start, self.segmentation_step)
        td, tm = divmod(end, self.segmentation_step)
        return range(self.segmentation_step * (fd + (1 if fm else 0)),
                     self.segmentation_step * td + 1,
                     self.segmentation_step)

    def is_residual(self, duration: int, total_duration: int = 0) -> bool:
        """

        :param duration: the duration to be checked
        :param total_duration: optional total length to check the duration against
        :return: True if this duration corresponds to a leftover of a note (that was removed, for instance)
        """
        return 0 < duration < self.atomic_size \
               or 0 < duration < self.residual_ratio * total_duration

    def is_full_fledged(self, duration: int, total_duration: int = 0) -> bool:
        """

        :param duration: the duration to be checked
        :param total_duration: optional total length to check the duration against
        :return: True if this duration corresponds to a part of a note that is long enough to be considered a note
        itself
        """
        return duration >= self.atomic_size \
               and duration >= self.residual_ratio * total_duration

    def split(self, t: int) -> Tuple['SmartSequence', 'SmartSequence']:
        """
        Split a sequence at the specified position, which is an integer value, and a multiple of the sequence
        `segmentation_step`

        :param t: the position where the sequence is split, an integer multiple of grid_spacing
        :return: two sub-sequences: the left sub-sequence (up to `t`) and the right sub-sequence (starting at `t`)
        """
        if t % self.segmentation_step != 0:
            raise ValueError(f'cannot split at position {t}, must be a multiple of {self.segmentation_step}')

        self._get_residue(0)
        self._get_residue(self.duration)
        self._get_residue(t)

        S_l = self.empty_copy(t)
        S_l.initial_start = self.initial_start

        S_r = self.empty_copy(self.duration - t)
        S_r.initial_start = t

        for pos in self._residues:
            if pos <= t:
                S_l._residues[pos] = self._get_residue(pos).copy()
            if pos >= t:
                S_r._residues[pos - t] = self._get_residue(pos).copy()

        for event in self:
            if event.end <= t:
                S_l._append(event)
            elif event.start >= t:
                S_r._append(event.translated_copy_by(-t))
            else:
                before, after = event.split(t)
                if not self.smart or self.is_full_fledged(before, before + after):
                    # the left part of the event is long enough to be kept in the left sequence
                    S_l._append(Interval(event.start, t, metadata=event.metadata))

                if not self.smart or self.is_full_fledged(after, before + after):
                    # the right part of the event is long enough to be kept in the right sequence
                    S_r._append(Interval(0, event.end - t, metadata=event.metadata))

        return S_l, S_r

    def concat(self, S2: 'SmartSequence') -> 'SmartSequence':
        if self.atomic_size != S2.atomic_size:
            raise ValueError(f'cannot concatenate sequences with different atomic sizes '
                             f'{self.atomic_size} ≠ {S2.atomic_size}')
        if self.segmentation_step != S2.segmentation_step:
            raise ValueError(f'cannot concatenate sequences with different segmentation steps '
                             f'{self.segmentation_step} ≠ {S2.segmentation_step}')
        if self.residual_ratio != S2.residual_ratio:
            raise ValueError(f'cannot concatenate sequences with different residual ratios '
                             f'{self.segmentation_step} ≠ {S2.residual_ratio}')

        S1 = self
        d1, d2 = S1.duration, S2.duration
        S = self.empty_copy(d1 + d2)
        for t in S1._residues:
            S._residues[t] = S1._get_residue(t)
        for t in S2._residues:
            S._residues[t + d1] = S2._get_residue(t)

        ll = S1._get_residue(d1).ll
        lr = S1._get_residue(d1).lr
        lr_is_residual = S1._get_residue(d1).lr_is_residual
        lb = S1._get_residue(d1).lb
        rl = S2._get_residue(0).rl
        rl_is_residual = S2._get_residue(0).rl_is_residual
        rr = S2._get_residue(0).rr
        rb = S2._get_residue(0).rb
        S._residues[d1] = Memory(ll=ll,
                                 lr=lr,
                                 lb=lb,
                                 rl=rl,
                                 rr=rr,
                                 rb=rb,
                                 lr_is_residual=lr_is_residual,
                                 rl_is_residual=rl_is_residual,
                                 l_metadata=S1._get_residue(d1).l_metadata,
                                 r_metadata=S2._get_residue(0).r_metadata)

        left_room = d1
        left_event_at_d1 = None
        for e in S1:
            if e.end < d1:
                S.append(e.copy())
                left_room = d1 - e.end
            elif e.end == d1:
                left_event_at_d1 = e.copy()
            else:
                raise ValueError(f'{e} exceed sequences end {self.duration}')

        right_event_at_d1 = None
        if S2.has_intervals() and S2[0].start == 0:
            right_event_at_d1 = S2[0].translated_copy_by(d1)

        if left_event_at_d1 and right_event_at_d1:
            if rb:
                S.append(left_event_at_d1)
                S.append(right_event_at_d1)
            else:
                left_event_at_d1.end = right_event_at_d1.end
                S.append(left_event_at_d1)
        elif left_event_at_d1:
            e2 = S2._intervals.head
            right_room = e2.start if e2 is not None else d2
            # _lr = lr if self.is_residual(lr, left_event_at_d1.duration + lr) else 0
            _lr = lr if lr_is_residual else 0
            left_event_at_d1.end = d1 + min(max(_lr, rr), right_room)
            S.append(left_event_at_d1)
        elif right_event_at_d1:
            if S2._get_residue(0).rb:
                S.append(right_event_at_d1)
            else:
                # _rl = rl if self.is_residual(rl, rl + right_event_at_d1.duration) else 0
                _rl = rl if rl_is_residual else 0
                right_event_at_d1.start = d1 - min(max(ll, _rl), left_room)
                S.append(right_event_at_d1)
        else:
            metadata = S1._get_residue(d1).l_metadata \
                if S1._get_residue(d1).l_metadata \
                else S2._get_residue(0).r_metadata
            if lb and rb:
                S.append(Interval(start=max(0, d1 - min(left_room, ll)),
                                  end=d1,
                                  metadata=metadata))
                if min(S.duration, d1 + rr) - d1 > 0:
                    S.append(Interval(start=d1,
                                      end=min(S.duration, d1 + rr),
                                      metadata=metadata))
            elif (lb or rb) \
                    or (ll + rr >= S.atomic_size) \
                    or (ll == rl and lr == rr and (ll or lr)):
                room = min(S.duration, d1 + rr) - max(0, d1 - ll)
                if room > 0:
                    S.append(Interval(start=max(0, d1 - min(left_room, ll)),
                                      end=min(S.duration, d1 + rr),
                                      metadata=metadata))

        for e in S2:  # type: Interval
            if e.start > 0:
                S.append(e.translated_copy_by(d1))

        return S

    def last_interval(self) -> Interval:
        return self._intervals.tail if self._intervals is not None else None

    def first_interval(self) -> Interval:
        return self._intervals.head if self._intervals is not None else None

    def _plot(self, ax, name, xmargin=.1):
        ax.margins(xmargin, 1)
        ax.grid(True, linestyle='-.')
        ax.axis["xzero"].set_axisline_style("-|>")
        ax.axis["xzero"].set_visible(True)
        ax.axis["xzero"].label.set_text(name)
        # ax.axis["xzero"].label.set_color('r')
        ax.axis["xzero"].label.set_axis_direction('right')
        ax.axis["xzero"].major_ticklabels.set_color("r")
        ax.axis["xzero"].major_ticklabels.set_pad(30)
        for direction in ["left", "right", "bottom", "top"]:
            # hides borders
            ax.axis[direction].set_visible(False)
        seg_pos = self.segmentation_positions(0, self.duration)
        ax.set_xticks(seg_pos)
        ax.set_yticks([])
        y = 1
        ax.plot([0, self.duration], [0, 0], linestyle='-', color='black', linewidth=1)
        for x in seg_pos:
            ax.plot([x, x], [-1, 1], linestyle='-', color='black', linewidth=1)
        for interval in self:
            rect = patches.Rectangle((interval.start, -.5), (interval.duration), 1,
                                     linewidth=1,
                                     edgecolor='r',
                                     facecolor='r')
            ax.add_patch(rect)

    def plot(self, name: str = 'No name'):
        fig = plt.figure(1, figsize=(16, 1.7), dpi=600)
        ax = SubplotZero(fig, 111)
        fig.add_subplot(ax)

        self._plot(ax, name)

        plt.show()
        # plt.savefig('Fig_S')
        plt.close()
