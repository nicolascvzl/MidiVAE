from copy import copy
from typing import Optional, Tuple


class Interval:
    """
    An interval with integer bounds, with non-negative bounds, but maybe of zero duration
    """

    # The lower bound
    _start: int
    # The upper boud
    _end: int
    # The optional metadata associated to this interval
    metadata: Optional[object]

    def __init__(self, start: int = 0, end: int = 0, metadata: object = None):
        self._start = start
        self._end = end
        self.metadata = metadata

    def __copy__(self):
        raise TypeError('cannot copy intervals')

    def __deepcopy__(self, memodict):
        raise TypeError('cannot copy intervals')

    def __str__(self):
        return f'[{self.start}, {self.end}]{" (" + str(self.metadata) + ")" if self.metadata is not None else ""}'

    def __eq__(self, other):
        if isinstance(self, other.__class__):
            return self.start == other.start and self.end == other.end
        return False

    def copy(self):
        return Interval(self.start, self.end, copy(self.metadata))

    @property
    def start(self) -> int:
        return self._start

    @start.setter
    def start(self, start: int):
        self._start = start

    @property
    def end(self) -> int:
        return self._end

    @end.setter
    def end(self, end: int):
        self._end = end

    @property
    def duration(self) -> int:
        return self._end - self._start

    def is_empty(self) -> bool:
        return self.duration == 0

    def translate_to(self, pos: int, in_place: bool = True) -> 'Interval':
        dur = self.duration
        if in_place:
            self.start = pos
            self.end = pos + dur
            return self
        else:
            return Interval(start=pos, end=pos + dur, metadata=self.metadata)

    def translated_copy_by(self, offset: int) -> 'Interval':
        return Interval(start=self.start + offset, end=self.end + offset, metadata=self.metadata)

    def split(self, pos: int) -> Tuple[int, int]:
        """
        Yields the duration of this interval before and after the specified position
        """
        p = min(max(pos, self.start), self.end)
        return p - self.start, self.end - p
